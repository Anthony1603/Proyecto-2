﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace Proyecto2
{
    public partial class Form1 : Form
    {
        //Declaracion de Variables
        int[,] TableroJuego = new int[6, 7];
        int Fila = 0; int Columna = 0;
        bool Jugador = true;

        int VictoriasJugador1 = 0;
        int VictoriasJugador2 = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void LlenarMatriz(int Columna)
        {
            //Ciclo para Colocar Imagenes de Jugadores de Abajo Hacia Arriba
            for (int i = 5; i > -1; i--)
            {
                //Condicional Jugador 1
                if (Jugador == true)
                {
                    //Si no hay Imagen de Ningun Jugador en una Casilla Darle el Valor del Jugador 1 
                    if ((TableroJuego[i, Columna] != 1) && (TableroJuego[i, Columna] != 2))
                    {
                        TableroJuego[i, Columna] = 1;
                        string Posicion = i.ToString() + Columna.ToString();
                        ReconocerBoton(Posicion);
                        break;
                    }
                }
                //Condicional Jugador 2
                else if (Jugador == false)
                {
                    //Si no hay Imagen de Ningun Jugador en una Casilla Darle el Valor del Jugador 2
                    if ((TableroJuego[i, Columna] != 2) && (TableroJuego[i, Columna] != 1))
                    {
                        TableroJuego[i, Columna] = 2;
                        string Posicion = i.ToString() + Columna.ToString();
                        ReconocerBoton(Posicion);
                        break;
                    }
                }
            }
        }


        private void ReconocerBoton(string Posicion)
        {
            //Declaracion de Parametros de las Imagenes
            int Ancho = 60;
            int Altura = 60;

            //Imagenes para cada Jugador
            System.Drawing.Image ImagenJugador1 = Properties.Resources.Jugador1_X;
            System.Drawing.Image ImagenJugador2 = Properties.Resources.Jugador2_O;

            //Modificacion del Tamaño de las Imagenes 
            System.Drawing.Image Imagen1 = new Bitmap(ImagenJugador1, new Size(Ancho, Altura));
            System.Drawing.Image Imagen2 = new Bitmap(ImagenJugador2, new Size(Ancho, Altura));

            //Si Imagen1 es True se Imprime, de lo Contrario Imprime Imagen2
            System.Drawing.Image ImagenTurno = Jugador ? Imagen1 : Imagen2;

            //Segun la Union de una Fila y una Columna Detecta a cual Boton Colocarle la Imagen
            switch (Posicion)
            {
                case "00":
                    button1.Image = ImagenTurno;
                    break;
                case "01":
                    button2.Image = ImagenTurno;
                    break;
                case "02":
                    button3.Image = ImagenTurno;
                    break;
                case "03":
                    button4.Image = ImagenTurno;
                    break;
                case "04":
                    button5.Image = ImagenTurno;
                    break;
                case "05":
                    button6.Image = ImagenTurno;
                    break;
                case "06":
                    button7.Image = ImagenTurno;
                    break;
                case "10":
                    button8.Image = ImagenTurno;
                    break;
                case "11":
                    button9.Image = ImagenTurno;
                    break;
                case "12":
                    button10.Image = ImagenTurno;
                    break;
                case "13":
                    button11.Image = ImagenTurno;
                    break;
                case "14":
                    button12.Image = ImagenTurno;
                    break;
                case "15":
                    button13.Image = ImagenTurno;
                    break;
                case "16":
                    button14.Image = ImagenTurno;
                    break;
                case "20":
                    button15.Image = ImagenTurno;
                    break;
                case "21":
                    button16.Image = ImagenTurno;
                    break;
                case "22":
                    button17.Image = ImagenTurno;
                    break;
                case "23":
                    button18.Image = ImagenTurno;
                    break;
                case "24":
                    button19.Image = ImagenTurno;
                    break;
                case "25":
                    button20.Image = ImagenTurno;
                    break;
                case "26":
                    button21.Image = ImagenTurno;
                    break;
                case "30":
                    button22.Image = ImagenTurno;
                    break;
                case "31":
                    button23.Image = ImagenTurno;
                    break;
                case "32":
                    button24.Image = ImagenTurno;
                    break;
                case "33":
                    button25.Image = ImagenTurno;
                    break;
                case "34":
                    button26.Image = ImagenTurno;
                    break;
                case "35":
                    button27.Image = ImagenTurno;
                    break;
                case "36":
                    button28.Image = ImagenTurno;
                    break;
                case "40":
                    button29.Image = ImagenTurno;
                    break;
                case "41":
                    button30.Image = ImagenTurno;
                    break;
                case "42":
                    button31.Image = ImagenTurno;
                    break;
                case "43":
                    button32.Image = ImagenTurno;
                    break;
                case "44":
                    button33.Image = ImagenTurno;
                    break;
                case "45":
                    button34.Image = ImagenTurno;
                    break;
                case "46":
                    button35.Image = ImagenTurno;
                    break;
                case "50":
                    button36.Image = ImagenTurno;
                    break;
                case "51":
                    button37.Image = ImagenTurno;
                    break;
                case "52":
                    button38.Image = ImagenTurno;
                    break;
                case "53":
                    button39.Image = ImagenTurno;
                    break;
                case "54":
                    button40.Image = ImagenTurno;
                    break;
                case "55":
                    button41.Image = ImagenTurno;
                    break;
                case "56":
                    button42.Image = ImagenTurno;
                    break;
            }
            //Si Jugador es True Pasara a False y Viceversa
            Jugador = !Jugador;

            //Metodos para Detectar al Ganador
            LineasHorizontales();
            LineasVerticales();
            LineasDiagonales();
            EspaciosLLenos();
        }


        private void LineasHorizontales()
        {
            //Ciclo para Revisar si hay 4 en Alguna Linea Horizontal
            for (int F = 5; F > -1; F--)
            {
                //Contadores para Detectar Ganador
                int Contador1 = 0;
                int Contador2 = 0;
                for (int C = 6; C > -1; C--)
                {
                    //Condicional Conteo de Imagenes Seguidas del Jugador 1
                    if (TableroJuego[F, C] == 1)
                    {
                        Contador1 += 1;
                        Contador2 = 0;
                    }
                    //Condicional Conteo de Imagenes Seguidas del Jugador 2
                    else if (TableroJuego[F, C] == 2)
                    {
                        Contador2 += 1;
                        Contador1 = 0;
                    }
                    //Condicional Espacio en Blanco
                    else
                    {
                        Contador1 = 0;
                        Contador2 = 0;
                    }

                    //Condicional si se Detectan 4 en Linea del Jugador 1
                    if (Contador1 >= 4)
                    {
                        MessageBox.Show("¡Gana el Jugador 1!");
                        VictoriasJugador1 += 1;
                        txtVictoriasJugador1.Text = VictoriasJugador1.ToString();
                        LimpiarPantalla();
                        break;
                    }
                    //Condicional si se Detectan 4 en Linea del Jugador 2
                    else if (Contador2 >= 4)   
                    {
                        MessageBox.Show("¡Gana el Jugador 2!");
                        VictoriasJugador2 += 1;
                        txtVictoriasJugador2.Text = VictoriasJugador2.ToString();
                        LimpiarPantalla();
                        break;
                    }
                }
            }
        }


        private void LineasVerticales()
        {
            //Ciclo para Revisar si hay 4 en Alguna Linea Vertical
            for (int C = 6; C > -1; C--)
            {
                //Contadores para Detectar Ganador
                int Contador1 = 0;
                int Contador2 = 0;
                for (int F = 5; F > -1; F--)
                {
                    //Condicional Conteo de Imagenes Seguidas del Jugador 1
                    if (TableroJuego[F, C] == 1)
                    {
                        Contador1 += 1;
                        Contador2 = 0;
                    }
                    //Condicional Conteo de Imagenes Seguidas del Jugador 2
                    else if (TableroJuego[F, C] == 2)
                    {
                        Contador2 += 1;
                        Contador1 = 0;
                    }
                    //Condicional Espacio en Blanco
                    else
                    {
                        Contador1 = 0;
                        Contador2 = 0;
                    }

                    //Condicional si se Detectan 4 en Linea del Jugador 1
                    if (Contador1 >= 4)
                    {
                        MessageBox.Show("¡Gana el Jugador 1!");
                        VictoriasJugador1 += 1;
                        txtVictoriasJugador1.Text = VictoriasJugador1.ToString();
                        LimpiarPantalla();
                        break;
                    }
                    //Condicional si se Detectan 4 en Linea del Jugador 2
                    else if (Contador2 >= 4)
                    {
                        MessageBox.Show("¡Gana el Jugador 2!");
                        VictoriasJugador2 += 1;
                        txtVictoriasJugador2.Text = VictoriasJugador2.ToString();
                        LimpiarPantalla();
                        break;
                    }
                }
            }
        }


        private void LineasDiagonales()
        {
            for (int i = 3; i < 6; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    // verifica apartir de la fila 3,busca fichas hacia abajo formando una diagonal
                    if (TableroJuego[i, j] != 0 &&
                        TableroJuego[i, j] == TableroJuego[i - 1, j + 1] &&
                        TableroJuego[i, j] == TableroJuego[i - 2, j + 2] &&
                        TableroJuego[i, j] == TableroJuego[i - 3, j + 3])
                    {
                        // Si se encuentra una línea de cuatro en diagonal 
                        if (TableroJuego[i, j] == 1)
                        {
                            MessageBox.Show("¡Gana el Jugador 1!");
                            VictoriasJugador1++;
                            txtVictoriasJugador1.Text = VictoriasJugador1.ToString();
                            LimpiarPantalla();
                        }
                        else if (TableroJuego[i, j] == 2)
                        {
                            MessageBox.Show("¡Gana el Jugador 2!");
                            VictoriasJugador2++;
                            txtVictoriasJugador2.Text = VictoriasJugador2.ToString();
                            LimpiarPantalla();
                        }
                        break;
                    }
                }
            }

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    // verifica apartir de la fila 0, y busca fichas formando una diagonal hacia arriba
                    if (TableroJuego[i, j] != 0 &&
                        TableroJuego[i, j] == TableroJuego[i + 1, j + 1] &&
                        TableroJuego[i, j] == TableroJuego[i + 2, j + 2] &&
                        TableroJuego[i, j] == TableroJuego[i + 3, j + 3])
                    {
                        // Si se encuentra una línea de cuatro en diagonal 
                        if (TableroJuego[i, j] == 1)
                        {
                            MessageBox.Show("¡Gana el Jugador 1!");
                            VictoriasJugador1++;
                            txtVictoriasJugador1.Text = VictoriasJugador1.ToString();
                            LimpiarPantalla();
                        }
                        else if (TableroJuego[i, j] == 2)
                        {
                            MessageBox.Show("¡Gana el Jugador 2!");
                            VictoriasJugador2++;
                            txtVictoriasJugador2.Text = VictoriasJugador2.ToString();
                            LimpiarPantalla();
                        }
                        break;
                    }
                }
            }
        }



        private void EspaciosLLenos()
        {
            int Contador = 0;
            for (int F = 5; F > -1; F--)
            {
                for (int C = 6; C > -1; C--)
                {
                    if (TableroJuego[F, C] != 0)
                    {
                        Contador += 1;
                    }
                }
            }
            if (Contador == 42)
            {
                MessageBox.Show("Todos los espacios estan llenos \nReiniciando el tablero....");
                LimpiarPantalla();
            }
        }



        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            //Posicion del Boton en el Panel
            int Fila = 0; int Columna = 0;
            LlenarMatriz(Columna);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int Fila = 0; int Columna = 1;
            LlenarMatriz(Columna);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int Fila = 0; int Columna = 2;
            LlenarMatriz(Columna);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int Fila = 0; int Columna = 3;
            LlenarMatriz(Columna);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int Fila = 0; int Columna = 4;
            LlenarMatriz(Columna);
        }
        private void button6_Click_1(object sender, EventArgs e)
        {
            int Fila = 0; int Columna = 5;
            LlenarMatriz(Columna);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            int Fila = 0; int Columna = 6;
            LlenarMatriz(Columna);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            int Fila = 1; int Columna = 0;
            LlenarMatriz(Columna);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            int Fila = 1; int Columna = 1;
            LlenarMatriz(Columna);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            int Fila = 1; int Columna = 2;
            LlenarMatriz(Columna);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            int Fila = 1; int Columna = 3;
            LlenarMatriz(Columna);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            int Fila = 1; int Columna = 4;
            LlenarMatriz(Columna);
        }

        private void button13_Click(object sender, EventArgs e)
        {
            int Fila = 1; int Columna = 5;
            LlenarMatriz(Columna);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            int Fila = 1; int Columna = 6;
            LlenarMatriz(Columna);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            int Fila = 2; int Columna = 0;
            LlenarMatriz(Columna);
        }

        private void button16_Click(object sender, EventArgs e)
        {
            int Fila = 2; int Columna = 1;
            LlenarMatriz(Columna);
        }

        private void button17_Click(object sender, EventArgs e)
        {
            int Fila = 2; int Columna = 2;
            LlenarMatriz(Columna);
        }

        private void button18_Click(object sender, EventArgs e)
        {
            int Fila = 2; int Columna = 3;
            LlenarMatriz(Columna);
        }

        private void button19_Click(object sender, EventArgs e)
        {
            int Fila = 2; int Columna = 4;
            LlenarMatriz(Columna);
        }

        private void button20_Click(object sender, EventArgs e)
        {
            int Fila = 2; int Columna = 5;
            LlenarMatriz(Columna);
        }

        private void button21_Click(object sender, EventArgs e)
        {
            int Fila = 2; int Columna = 6;
            LlenarMatriz(Columna);
        }

        private void button22_Click(object sender, EventArgs e)
        {
            int Fila = 3; int Columna = 0;
            LlenarMatriz(Columna);
        }

        private void button23_Click(object sender, EventArgs e)
        {
            int Fila = 3; int Columna = 1;
            LlenarMatriz(Columna);
        }

        private void button24_Click(object sender, EventArgs e)
        {
            int Fila = 3; int Columna = 2;
            LlenarMatriz(Columna);
        }

        private void button25_Click(object sender, EventArgs e)
        {
            int Fila = 3; int Columna = 3;
            LlenarMatriz(Columna);
        }

        private void button26_Click(object sender, EventArgs e)
        {
            int Fila = 3; int Columna = 4;
            LlenarMatriz(Columna);
        }

        private void button27_Click(object sender, EventArgs e)
        {
            int Fila = 3; int Columna = 5;
            LlenarMatriz(Columna);
        }

        private void button28_Click(object sender, EventArgs e)
        {
            int Fila = 3; int Columna = 6;
            LlenarMatriz(Columna);
        }

        private void button29_Click(object sender, EventArgs e)
        {
            int Fila = 4; int Columna = 0;
            LlenarMatriz(Columna);
        }

        private void button30_Click(object sender, EventArgs e)
        {
            int Fila = 4; int Columna = 1;
            LlenarMatriz(Columna);
        }

        private void button31_Click(object sender, EventArgs e)
        {
            int Fila = 4; int Columna = 2;
            LlenarMatriz(Columna);
        }

        private void button32_Click(object sender, EventArgs e)
        {
            int Fila = 4; int Columna = 3;
            LlenarMatriz(Columna);
        }

        private void button33_Click(object sender, EventArgs e)
        {
            int Fila = 4; int Columna = 4;
            LlenarMatriz(Columna);
        }

        private void button34_Click(object sender, EventArgs e)
        {
            int Fila = 4; int Columna = 5;
            LlenarMatriz(Columna);
        }

        private void button35_Click(object sender, EventArgs e)
        {
            int Fila = 4; int Columna = 6;
            LlenarMatriz(Columna);
        }

        private void button36_Click(object sender, EventArgs e)
        {
            int Fila = 5; int Columna = 0;
            LlenarMatriz(Columna);
        }

        private void button37_Click(object sender, EventArgs e)
        {
            int Fila = 5; int Columna = 1;
            LlenarMatriz(Columna);
        }

        private void button38_Click(object sender, EventArgs e)
        {
            int Fila = 5; int Columna = 2;
            LlenarMatriz(Columna);
        }

        private void button39_Click(object sender, EventArgs e)
        {
            int Fila = 5; int Columna = 3;
            LlenarMatriz(Columna);
        }

        private void button40_Click(object sender, EventArgs e)
        {
            int Fila = 5; int Columna = 4;
            LlenarMatriz(Columna);
        }

        private void button41_Click(object sender, EventArgs e)
        {
            int Fila = 5; int Columna = 5;
            LlenarMatriz(Columna);
        }

        private void button42_Click(object sender, EventArgs e)
        {
            int Fila = 5; int Columna = 6;
            LlenarMatriz(Columna);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //Metodo de PictureBox para Salir del Programa
            if (MessageBox.Show("Desea salir del programa", "Confirmar",
             MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Environment.Exit(0);
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            //Metodo de PictureBox para Reiniciar el Programa
            if (MessageBox.Show("Desea reiniciar toda la partida", "Confirmar",
             MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                //Inicializacion de los Contadores de Victorias
                VictoriasJugador1 = 0;
                VictoriasJugador2 = 0;
                txtVictoriasJugador1.Text = VictoriasJugador1.ToString();
                txtVictoriasJugador2.Text = VictoriasJugador2.ToString();

                LimpiarPantalla();
            }
        }

        private void LimpiarPantalla()
        {
            //Inicializacion de Booleanos
            Jugador = true;

            //Inicializacion de Casillas de Matriz TableroJuego
            for (int F = 5; F > -1; F--)
            {
                for (int C = 6; C > -1; C--)
                {
                    TableroJuego[F, C] = 0;
                }
            }

            //Quitar las Imagenes de los Jugadores
            button1.Image = null;
            button2.Image = null;
            button3.Image = null;
            button4.Image = null;
            button5.Image = null;
            button6.Image = null;
            button7.Image = null;
            button8.Image = null;
            button9.Image = null;
            button10.Image = null;
            button11.Image = null;
            button12.Image = null;
            button13.Image = null;
            button14.Image = null;
            button15.Image = null;
            button16.Image = null;
            button17.Image = null;
            button18.Image = null;
            button19.Image = null;
            button20.Image = null;
            button21.Image = null;
            button22.Image = null;
            button23.Image = null;
            button24.Image = null;
            button25.Image = null;
            button26.Image = null;
            button27.Image = null;
            button28.Image = null;
            button29.Image = null;
            button30.Image = null;
            button31.Image = null;
            button32.Image = null;
            button33.Image = null;
            button34.Image = null;
            button35.Image = null;
            button36.Image = null;
            button37.Image = null;
            button38.Image = null;
            button39.Image = null;
            button40.Image = null;
            button41.Image = null;
            button42.Image = null;
        }
    }
}
